'use strict';

/** @type {import('./syntax')} */
module.exports = SyntaxError;
